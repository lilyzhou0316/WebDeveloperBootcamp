/*
 * @Author: Xiaoli Zhou
 * @Date: 2015-10-31 20:20:56
 * @LastEditTime: 2020-03-31 23:05:37
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /TodoListApp/todolist.js
 */

//check off specific todos by clicking
$("ul").on("click", "li", function () {
    /* //if li is gray, turn it black
    if ($(this).css("color") === "rgb(128, 128, 128)") {
        $(this).css({
            "color": "black",
            "text-decoration": "none"
        })
    } else { //else, turn it gray
        $(this).css({
            "color": "gray",
            "text-decoration": "line-through"
        })
    }所有上面的code就等于下面的code */
    $(this).toggleClass("completed");
});
//click on x to delete todo
$("ul").on("click", "span", function (event) {
    $(this).parent().fadeOut(500, function () {
        $(this).remove();
    });
    //to stop the action bubble up to all parents
    event.stopPropagation();
});

$("input[type='text']").keypress(function (e) {
    //check if the key is enter key
    if (e.which === 13) {
        //grab new todo text from input text field
        var todoText = $(this).val();
        //clean the input text field
        $(this).val("");
        //create a new li and add it to ul
        $("ul").append("<li><span><i class='fa fa-trash'></i></span> " + todoText + "</li>");

    }
});

$(".fa-plus").click(function () {
    $("input[type='text']").fadeToggle();
})